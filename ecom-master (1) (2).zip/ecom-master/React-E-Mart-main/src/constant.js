export const ENV = "PROD";
// export const ENV = "DEV";

export const BASE_URL = {
  DEV: "http://localhost:8080",
  PROD: "https://ecom-backend-six-xi.vercel.app",
};
